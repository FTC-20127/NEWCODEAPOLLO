package org.firstinspires.ftc.teamcode.mechanisms;

import com.qualcomm.hardware.lynx.LynxModule;
import com.qualcomm.hardware.rev.RevHubOrientationOnRobot;
import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.IMU;
import com.qualcomm.robotcore.hardware.Servo;

import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;

/*
 * MAIN TeleOp: everything from "BIOBUZZ Drive Only" (drive, intake, passthrough, shooter, hood)
 * PLUS the Limelight and turret tracking.
 *
 * One gamepad, EXACTLY the same buttons as BIOBUZZ Drive Only.
 * The turret tracks the target from START, up to 180° each way (360° total, Turret.TRAVEL_DEG).
 * B turns tracking off (turret goes straight ahead) and on again.
 * Set ALLIANCE below before each match. Power on with the turret roughly straight ahead.
 *
 * GAMEPAD 1:
 *   Left stick            : drive (field relative)
 *   Right stick X         : turn
 *   Right stick press     : switch robot relative / field relative
 *   Left stick press      : slow mode on/off
 *   X                     : reset field heading (also resets when you press START)
 *   Right trigger / bumper: intake in / reverse (hold)
 *   Left bumper / trigger : passthrough forward / reverse (hold)
 *   Y                     : shooter on/off
 *   A                     : hood POLLEN, press again for NORMAL (toggle)
 *   B                     : turret tracking on/off (toggle; on at START)
 *
 * CHANGES vs. previous version:
 *   1. Hood is commanded at START (servos are limp until the first setPosition()).
 *   2. Hood pushes HOOD_FEED_PUSH extra while feeding, so the ball can't shove it back.
 *   3. Shooter gets SHOOTER_FEED_BOOST extra power while feeding, and full power when
 *      it is more than SHOOTER_BANG_BAND RPM below target (tighter 4-ball bursts).
 *   4. Faster loop: bulk reads on the hubs, IMU read once per loop.
 */
@TeleOp(name = "Main TeleOp", group = "Competition")
public class MainTeleop extends OpMode {

    public static double DRIVE_ANGLE_OFFSET_DEG = 0;

    public static double MAX_SPEED = 1.0;        // lower this for outreach events
    public static double SLOW_MODE_SCALE = 0.4;  // drive speed while slow mode is on

    // ---------- mechanism settings (same as BIOBUZZ Drive Only) ----------
    public static double SHOOTER_MAX_RPM = 7750.0;
    public static double SHOOTER_TICKS_PER_REV = 28.0;
    public static double SHOOTER_KF = 1.0 / 6000.0;
    public static double SHOOTER_KP = 0.0004;
    public static double SHOOTER_KI = 0.0001;
    public static double SHOOTER_FILTER = 0.6;        // was 0.3: higher = reacts to drops sooner

    // NEW: burst settings
    public static double SHOOTER_FEED_BOOST = 0.15;   // extra power while feeding (LB). First ball long -> lower. Last ball short -> raise.
    public static double SHOOTER_BANG_BAND  = 150;    // full power if this many RPM below target

    public static double INTAKE_POWER = 1.0;
    public static double PASSTHROUGH_POWER = 1.0;
    public static double TRIGGER_DEADZONE = 0.1;

    public static double HOOD_POLLEN_POSITION = 0.40;  // A
    public static double HOOD_NORMAL_POSITION = 0.10;  // A again

    // NEW: extra hood push while feeding. If shots get WORSE or the hood moves away from
    // the ball while feeding, flip the sign (-0.02). Raise in 0.01 steps until the hood
    // stops moving; don't go far past that or the servo gets hot.
    public static double HOOD_FEED_PUSH = 0.02;

    // ---------- turret ----------
    /** OUR ALLIANCE: set RED or BLUE before each match. The turret only tracks this alliance's HIVE. */
    public static LimelightVision.Alliance ALLIANCE = LimelightVision.Alliance.BLUE;

    DcMotor frontLeftDrive;
    DcMotor frontRightDrive;
    DcMotor backLeftDrive;
    DcMotor backRightDrive;
    IMU imu;

    DcMotor intake;
    DcMotor passthrough;
    DcMotorEx shooterLeft;
    DcMotorEx shooterRight;
    Servo hood;

    LimelightVision vision;
    Turret turret;
    LimelightVision.Alliance alliance;
    LimelightVision.Target target;

    boolean shooterOn = false, lastY = false;
    boolean hoodPollen = false, lastA = false;
    boolean tracking = true, lastB = false;
    double filteredRpm = 0;
    double shooterIntegral = 0;
    double lastLoopTime = 0;
    double shooterPower = 0;
    double hoodTarget = 0;
    boolean slowMode = false, lastLeftStickBtn = false;
    boolean robotRelative = false, lastRightStickBtn = false;
    String hoodMode = "NORMAL";

    // RPM table (added): POLLEN shooter speed from the Limelight distance
    double totalTargetRpm = 0;
    double burstTotalRpm = 0;
    boolean wasFeeding = false;

    // IMU values, read once per loop
    double headingDeg = 0;
    double headingRad = 0;
    double turnRateDegPerSec = 0;

    // loop timing for telemetry
    double loopMs = 0;

    @Override
    public void init() {
        // Bulk reads: all motor encoders on a hub are read in one go -> faster loop
        for (LynxModule hub : hardwareMap.getAll(LynxModule.class)) {
            hub.setBulkCachingMode(LynxModule.BulkCachingMode.AUTO);
        }

        frontLeftDrive  = hardwareMap.get(DcMotor.class, "front_left_drive");
        frontRightDrive = hardwareMap.get(DcMotor.class, "front_right_drive");
        backLeftDrive   = hardwareMap.get(DcMotor.class, "back_left_drive");
        backRightDrive  = hardwareMap.get(DcMotor.class, "back_right_drive");

        frontLeftDrive.setDirection(DcMotor.Direction.REVERSE);
        frontRightDrive.setDirection(DcMotor.Direction.REVERSE);
        backRightDrive.setDirection(DcMotor.Direction.REVERSE);

        frontLeftDrive.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        frontRightDrive.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        backLeftDrive.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        backRightDrive.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);

        imu = hardwareMap.get(IMU.class, "imu");
        RevHubOrientationOnRobot orientationOnRobot = new RevHubOrientationOnRobot(
                RevHubOrientationOnRobot.LogoFacingDirection.LEFT,
                RevHubOrientationOnRobot.UsbFacingDirection.UP);
        imu.initialize(new IMU.Parameters(orientationOnRobot));

        intake       = hardwareMap.get(DcMotor.class,   "intake");
        passthrough  = hardwareMap.get(DcMotor.class,   "passthrought");
        shooterLeft  = hardwareMap.get(DcMotorEx.class, "shooter_left");
        shooterRight = hardwareMap.get(DcMotorEx.class, "Shooter_right");
        hood         = hardwareMap.get(Servo.class,     "hood");

        intake.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        passthrough.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);

        shooterLeft.setDirection(DcMotorSimple.Direction.REVERSE);
        shooterRight.setDirection(DcMotorSimple.Direction.REVERSE);
        // Our own speed control below sets the power; the encoders are only read
        shooterLeft.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        shooterRight.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        shooterLeft.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        shooterRight.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        shooterLeft.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.FLOAT);
        shooterRight.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.FLOAT);

        // ---------- camera + turret ----------
        vision = new LimelightVision(hardwareMap);
        turret = new Turret(hardwareMap);
        vision.start();
        turret.init();
        alliance = ALLIANCE;
    }

    @Override
    public void init_loop() {
        vision.update(alliance);
        turret.update();   // reads the encoder only; nothing moves before START

        telemetry.addData("Alliance (set in MainTeleOp.ALLIANCE)", alliance);
        telemetry.addData("Camera", vision.status());
        telemetry.addData("Tags seen", vision.tagsSeen());
        if (!Turret.USE_ENCODER) {
            telemetry.addLine("Turret encoder OFF (Turret.USE_ENCODER = false): camera + IMU only,");
            telemetry.addLine("NO wire limit: watch the wires.");
        } else {
            telemetry.addData("Encoder volts", "%.3f", turret.encoderVolts());
            telemetry.addData("Turret angle", "%.1f", turret.angleDeg());
            if (!turret.homeSet()) {
                telemetry.addLine("Turret HOME_VOLTAGE not set: point the turret straight ahead,");
                telemetry.addLine("copy 'Encoder volts' into Turret.HOME_VOLTAGE.");
            }
        }
    }

    @Override
    public void start() {
        imu.resetYaw();   // whatever way the robot faces at START is "forward"
        turret.start();
        tracking = true;

        // Servos are limp until the first setPosition(): hold the hood from the very start
        hoodPollen = false;
        hoodMode = "NORMAL";
        hood.setPosition(HOOD_NORMAL_POSITION);

        lastLoopTime = getRuntime();
    }

    @Override
    public void loop() {
        // ---------- timing ----------
        double now = getRuntime();
        double rawDt = now - lastLoopTime;
        double dt = Math.max(0.0, Math.min(0.1, rawDt));
        lastLoopTime = now;
        loopMs = rawDt * 1000.0;

        // ---------- read IMU ONCE per loop ----------
        if (gamepad1.x) { imu.resetYaw(); turret.forgetTagDirection(); }
        headingDeg = imu.getRobotYawPitchRollAngles().getYaw(AngleUnit.DEGREES);
        headingRad = Math.toRadians(headingDeg);
        turnRateDegPerSec = imu.getRobotAngularVelocity(AngleUnit.DEGREES).zRotationRate;

        // ---------- drive ----------
        if (gamepad1.left_stick_button && !lastLeftStickBtn) slowMode = !slowMode;
        lastLeftStickBtn = gamepad1.left_stick_button;
        if (gamepad1.right_stick_button && !lastRightStickBtn) robotRelative = !robotRelative;
        lastRightStickBtn = gamepad1.right_stick_button;

        double forward = -gamepad1.left_stick_y;
        double right   = -gamepad1.left_stick_x;
        double rotate  = -gamepad1.right_stick_x;
        double speed   = slowMode ? MAX_SPEED * SLOW_MODE_SCALE : MAX_SPEED;

        if (robotRelative) {
            drive(forward, right, rotate, speed);
        } else {
            driveFieldRelative(forward, right, rotate, speed);
        }

        // ---------- intake: RT = in, RB = reverse ----------
        if (gamepad1.right_trigger > TRIGGER_DEADZONE) {
            intake.setPower(INTAKE_POWER);
        } else if (gamepad1.right_bumper) {
            intake.setPower(-INTAKE_POWER);
        } else {
            intake.setPower(0);
        }

        // ---------- passthrough: LB = forward, LT = reverse ----------
        boolean feedingForward = gamepad1.left_bumper;
        if (feedingForward) {
            passthrough.setPower(PASSTHROUGH_POWER);
        } else if (gamepad1.left_trigger > TRIGGER_DEADZONE) {
            passthrough.setPower(-PASSTHROUGH_POWER);
        } else {
            passthrough.setPower(0);
        }

        // ---------- shooter: Y toggles on/off ----------
        if (gamepad1.y && !lastY) shooterOn = !shooterOn;
        lastY = gamepad1.y;

        boolean feeding = shooterOn && feedingForward;   // balls going into the flywheel

        double leftRpmNow  = Math.abs(shooterLeft.getVelocity())  / SHOOTER_TICKS_PER_REV * 60.0;
        double rightRpmNow = Math.abs(shooterRight.getVelocity()) / SHOOTER_TICKS_PER_REV * 60.0;
        double measuredRpm = Math.max(leftRpmNow, rightRpmNow);
        filteredRpm += SHOOTER_FILTER * (measuredRpm - filteredRpm);

        // RPM table (added): hood on POLLEN + a distance from the camera -> RPM from PollenRpmTable.
        // Otherwise SHOOTER_MAX_RPM, same as before. Held steady while feeding (rapid fire).
        totalTargetRpm = SHOOTER_MAX_RPM;
        if (hoodPollen && target != null && !Double.isNaN(target.distanceIn())) {
            totalTargetRpm = PollenRpmTable.totalRpmFor(target.distanceIn());
        }
        if (feeding && !wasFeeding) burstTotalRpm = totalTargetRpm;
        if (feeding) totalTargetRpm = burstTotalRpm;
        wasFeeding = feeding;
        double targetRpm = totalTargetRpm / 2.0;
        if (shooterOn) {
            double error = targetRpm - filteredRpm;
            shooterIntegral += error * dt;
            double maxIntegral = 0.3 / SHOOTER_KI;
            shooterIntegral = Math.max(-maxIntegral, Math.min(maxIntegral, shooterIntegral));

            shooterPower = SHOOTER_KF * targetRpm + SHOOTER_KP * error + SHOOTER_KI * shooterIntegral;
            if (feeding) shooterPower += SHOOTER_FEED_BOOST;   // fill the dip before it happens
            if (error > SHOOTER_BANG_BAND) shooterPower = 1.0; // way below target: full power
            shooterPower = Math.max(0.0, Math.min(1.0, shooterPower));
        } else {
            shooterPower = 0;
            shooterIntegral = 0;
        }
        shooterLeft.setPower(shooterPower);
        shooterRight.setPower(shooterPower);

        double totalRpm = filteredRpm * 2.0;

        // ---------- hood: A toggles POLLEN / NORMAL, extra push while feeding ----------
        if (gamepad1.a && !lastA) {
            hoodPollen = !hoodPollen;
            hoodMode = hoodPollen ? "POLLEN" : "NORMAL";
        }
        lastA = gamepad1.a;

        hoodTarget = hoodPollen ? HOOD_POLLEN_POSITION : HOOD_NORMAL_POSITION;
        if (feeding) hoodTarget += HOOD_FEED_PUSH;
        hoodTarget = Math.max(0.0, Math.min(1.0, hoodTarget));
        hood.setPosition(hoodTarget);

        // ---------- B toggles turret tracking ----------
        if (gamepad1.b && !lastB) tracking = !tracking;   // off: turret goes straight ahead
        lastB = gamepad1.b;

        // Tracking: turn until the tag is centred (tx), and counter-turn against the robot's own
        // turning (IMU), so it stays on the tags while driving.
        target = vision.update(alliance);
        if (tracking) {
            turret.track(target == null ? Double.NaN : target.txDeg, turnRateDegPerSec, headingDeg);
        } else {
            turret.home();
        }
        turret.update();

        // ---------- telemetry ----------
        telemetry.addData("Loop time", "%.0f ms", loopMs);
        telemetry.addData("Mode (R stick press)", robotRelative ? "ROBOT relative" : "FIELD relative");
        telemetry.addData("Slow mode (L stick press)", slowMode ? "ON" : "off");
        telemetry.addData("Heading", "%.1f°", headingDeg);
        telemetry.addData("Shooter (Y)", shooterOn ? (feeding ? "ON - FEEDING" : "ON") : "off");
        telemetry.addData("Shooter RPM total / target", "%.0f / %.0f",
                totalRpm, shooterOn ? totalTargetRpm : 0.0);
        telemetry.addData("Shooter RPM L / R", "%.0f / %.0f", leftRpmNow, rightRpmNow);
        telemetry.addData("Shooter power", "%.2f", shooterPower);
        telemetry.addData("Hood (A toggles)", "%s  pos %.3f", hoodMode, hoodTarget);
        telemetry.addData("Turret tracking (B toggles)", tracking ? "ON" : "OFF (straight ahead)");
        telemetry.addData("Intake / Passthrough power", "%.2f / %.2f",
                intake.getPower(), passthrough.getPower());

        telemetry.addData("Alliance", alliance);
        telemetry.addData("Camera", vision.status());
        telemetry.addData("Tags seen", vision.tagsSeen());
        telemetry.addData("Target", target == null ? "none"
                : String.format("%s · tx %+.1f° · %.1f in", target.name, target.txDeg, target.distanceIn()));
        telemetry.addData("Turret", "%.1f° from start (limit ±%.0f)  power %+.2f  (%s)",
                turret.angleFromStartDeg(), Turret.TRAVEL_DEG, turret.power(), turret.note());
    }

    @Override
    public void stop() {
        drive(0, 0, 0, 0);
        intake.setPower(0);
        passthrough.setPower(0);
        shooterLeft.setPower(0);
        shooterRight.setPower(0);
        turret.stop();
        vision.stop();
    }

    private void driveFieldRelative(double forward, double right, double rotate, double speed) {
        double theta = Math.atan2(forward, right);
        double r = Math.hypot(right, forward);

        theta = AngleUnit.normalizeRadians(theta + headingRad);   // uses the heading read at the top of loop()

        drive(r * Math.sin(theta), r * Math.cos(theta), rotate, speed);
    }

    // Thanks to FTC16072 for sharing this code!!
    public void drive(double forward, double right, double rotate, double speed) {
        if (DRIVE_ANGLE_OFFSET_DEG != 0) {
            double a = Math.toRadians(DRIVE_ANGLE_OFFSET_DEG);
            double f = forward * Math.cos(a) + right * Math.sin(a);
            double r = right * Math.cos(a) - forward * Math.sin(a);
            forward = f;
            right = r;
        }

        double frontLeftPower  = forward + right + rotate;
        double frontRightPower = forward - right - rotate;
        double backRightPower  = forward + right - rotate;
        double backLeftPower   = forward - right + rotate;

        double maxPower = 1.0;
        maxPower = Math.max(maxPower, Math.abs(frontLeftPower));
        maxPower = Math.max(maxPower, Math.abs(frontRightPower));
        maxPower = Math.max(maxPower, Math.abs(backRightPower));
        maxPower = Math.max(maxPower, Math.abs(backLeftPower));

        frontLeftDrive.setPower(speed * (frontLeftPower / maxPower));
        frontRightDrive.setPower(speed * (frontRightPower / maxPower));
        backLeftDrive.setPower(speed * (backLeftPower / maxPower));
        backRightDrive.setPower(speed * (backRightPower / maxPower));
    }
}
