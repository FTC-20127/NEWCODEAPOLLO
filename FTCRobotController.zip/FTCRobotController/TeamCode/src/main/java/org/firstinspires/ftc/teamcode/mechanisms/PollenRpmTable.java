package org.firstinspires.ftc.teamcode.mechanisms;

import java.util.Arrays;

/**
 * POLLEN shooter speed by distance: YOUR look-up table.
 *
 * <h2>Where the distance is measured</h2>
 * Along the floor, from the CENTRE OF THE TURRET to the spot on the floor DIRECTLY UNDER THE
 * MIDDLE OF THE CELL you shoot into. That is the same distance the Limelight reports on the
 * Driver Station "Target" line, which is what the robot looks up during a match.
 *
 * <h2>How to fill it in (MainTeleOp with TUNE_MODE = true)</h2>
 * <ol>
 *   <li>Put a tape mark on the field. Measure its distance (above) with a tape measure.</li>
 *   <li>Park the robot on the mark. Check the "Target ... in" number on the Driver Station is
 *       close to your tape (within ~2 in). If it isn't, trust the tape and tell your programmer.</li>
 *   <li>Hood POLLEN (A), shooter on (Y). Shoot. D-pad UP = +50 RPM, D-pad DOWN = -50 RPM,
 *       until it scores every time.</li>
 *   <li>Write the "WRITE DOWN" numbers from the screen into a row below:  { distance, rpm },</li>
 *   <li>Repeat on as many marks as you like. Rows can be in any order; add or delete rows freely.</li>
 * </ol>
 * Between two rows the RPM is blended in a straight line. Closer than the nearest row uses the
 * nearest row's RPM; further than the furthest row uses the furthest row's RPM.
 *
 * <p>RPM is TOTAL (both shooter motors added together), the same as SHOOTER_MAX_RPM. Each motor
 * tops out near 6000, so don't go above ~11500 total.
 */
public final class PollenRpmTable {

    private PollenRpmTable() {
    }

    /**
     * { distance in inches, TOTAL RPM }. Every row starts at 7750 (your current speed):
     * nothing changes until you measure. Replace the RPMs with what you measure.
     */
    public static double[][] TABLE = {
            //  distance (in)   total RPM
            {   24,             7750 },
            {   30,             7750 },
            {   36,             7750 },
            {   42,             7750 },
            {   48,             7750 },
            {   54,             7750 },
            {   60,             7750 },
            {   66,             7750 },
            {   72,             7750 },
            {   78,             7750 },
            {   84,             7750 },
            {   90,             7750 },
            {   96,             7750 },
            {  102,             7750 },
            {  108,             7750 },
            {  114,             7750 },
            {  120,             7750 },
            {  126,             7750 },
            {  132,             7750 },
            {  138,             7750 },
            {  144,             7750 },
    };

    /** Total RPM for {@code distanceIn} from the table, or NaN if the distance is unknown. */
    public static double totalRpmFor(double distanceIn) {
        if (Double.isNaN(distanceIn) || TABLE.length == 0) return Double.NaN;
        double[][] rows = TABLE.clone();
        Arrays.sort(rows, (a, b) -> Double.compare(a[0], b[0]));   // any order is fine
        if (distanceIn <= rows[0][0]) return rows[0][1];
        for (int i = 1; i < rows.length; i++) {
            if (distanceIn <= rows[i][0]) {
                double d0 = rows[i - 1][0], d1 = rows[i][0];
                if (d1 == d0) return rows[i][1];
                double t = (distanceIn - d0) / (d1 - d0);
                return rows[i - 1][1] + t * (rows[i][1] - rows[i - 1][1]);
            }
        }
        return rows[rows.length - 1][1];
    }
}
