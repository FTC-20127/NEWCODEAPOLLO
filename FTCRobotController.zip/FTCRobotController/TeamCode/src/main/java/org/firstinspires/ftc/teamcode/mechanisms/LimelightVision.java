package org.firstinspires.ftc.teamcode.mechanisms;

import com.qualcomm.hardware.limelightvision.LLResult;
import com.qualcomm.hardware.limelightvision.LLResultTypes;
import com.qualcomm.hardware.limelightvision.Limelight3A;
import com.qualcomm.robotcore.hardware.HardwareMap;

import org.firstinspires.ftc.robotcore.external.navigation.DistanceUnit;
import org.firstinspires.ftc.robotcore.external.navigation.Pose3D;
import org.firstinspires.ftc.robotcore.external.navigation.Position;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Limelight 3A: finds our HIVE CELL. Gives the AIM angle (where to point the shooter) and the
 * DISTANCE to the CELL (for the shooter RPM table).
 * Based on the BIOBUZZ GitHub LimelightVisionSubsystem / CameraMount / CellSighting.
 *
 * <p>The camera rides on the turret, so the aim angle is how far the turret (or, with the
 * turret off, the robot) still has to turn.
 *
 * <p>AIM: uses the Limelight's tx (left/right angle in the picture), the same as the version
 * that tracked. With 2+ tags of a CELL in view it aims at the MIDDLE of the CELL, worked out from
 * how far apart the tags are in the picture (just averaging the visible tags aims at whichever
 * end of the CELL is in view). No 3D needed for aiming. SHOT_OFFSET_DEG corrects shots that
 * always land to one side.
 *
 * <p>DISTANCE: along the floor from the turret pivot to the middle of the CELL, smoothed over the
 * last few camera frames so one noisy frame doesn't change the shooter RPM.
 *
 * <p>HIVE tags: 30–33 RED SCORING, 34–37 RED AUDIENCE, 38–41 BLUE AUDIENCE, 42–45 BLUE SCORING.
 *
 * <p>Limelight web page, pipeline 0: Fiducial Markers, AprilTag Classic 36h11, marker size
 * 82.55 mm, Full 3D Targeting = Yes, camera pose all 0.
 */
public class LimelightVision {

    public enum Alliance { RED, BLUE }

    // ---------------------------------------------------------------- settings
    /** Limelight pipeline to use. */
    public static int PIPELINE = 0;

    /** Lens position with the turret pointing straight ahead, from the turret pivot (robot centre). From CAD. */
    public static double CAM_FORWARD_IN = 4.37;   // 111 mm
    public static double CAM_LEFT_IN = 0.0;
    /** Lens height above the floor. Only affects the height number, not the aim or the distance. */
    public static double CAM_UP_IN = 12.53;       // 318 mm (CAD); you measured ~10-12, either is fine
    /** Camera tilt, degrees, + = aimed up. This one DOES matter for the distance: keep it accurate. */
    public static double CAM_PITCH_DEG = 45.0;
    /** Camera turn relative to the turret, degrees, + = left. Leave 0. */
    public static double CAM_YAW_DEG = 0.0;

    /**
     * Shots always land to one side? Degrees the shots land to the RIGHT of the CELL (use a
     * negative number if they land to the LEFT). The aim is shifted the other way to cancel it.
     * Start with 2–3°, adjust until shots land in the middle.
     */
    public static double SHOT_OFFSET_DEG = 0.0;

    /**
     * Practice mode: if no HIVE tag of our alliance is in view, follow the other alliance's
     * CELL, else the biggest non-HIVE tag. <b>Set false for matches.</b>
     */
    public static boolean TRACK_ANY_TAG = true;
    /**
     * Aim with the 3D position instead of tx. Leave false: tx is what's proven on the robot.
     * Only try true once the Target line shows sensible distances.
     */
    public static boolean USE_3D_AIM = false;

    /** Ignore camera results older than this, ms. */
    public static double MAX_AGE_MS = 300;

    /** Distance = median of the last this-many camera frames (smooths out noisy frames). */
    public static int DISTANCE_SMOOTH_FRAMES = 5;

    /**
     * Stay locked on a CELL this long after its tags drop out before switching to the other
     * CELL (stops the aim jumping between the two CELLs during rapid fire). ms.
     */
    public static double LOCK_HOLD_MS = 400;

    /** Lateral offsets of the 4 tags in a CELL from its centre, inches (from the FTC SDK). */
    private static final double[] TAG_OFFSET_IN = {-6.5, -2.75, 2.75, 6.5};
    private static final String[] CELL_NAMES = {"RED SCORING", "RED AUDIENCE", "BLUE AUDIENCE", "BLUE SCORING"};

    // ---------------------------------------------------------------- result
    /** The target this frame. */
    public static class Target {
        public final String name;
        public final int tagCount;
        /** Raw Limelight tx (average of the visible tags), degrees, + = RIGHT. */
        public final double txDeg;
        /**
         * Where to point: degrees the middle of the CELL is from where the shooter points,
         * + = RIGHT, with SHOT_OFFSET_DEG already applied. Turn until this is 0.
         */
        public final double aimDeg;
        /** Position from the turret pivot (+x forward, +y left, +z up), inches; null without Full 3D. */
        public final double[] pos;
        private final double smoothedDistanceIn;
        /** True when the aim came from the 3D middle of the CELL (better than raw tx). */
        public final boolean aim3d;

        Target(String name, int tagCount, double txDeg, double aimDeg, double[] pos,
               double smoothedDistanceIn, boolean aim3d) {
            this.name = name;
            this.tagCount = tagCount;
            this.txDeg = txDeg;
            this.aimDeg = aimDeg;
            this.pos = pos;
            this.smoothedDistanceIn = smoothedDistanceIn;
            this.aim3d = aim3d;
        }

        /** Distance along the floor to the middle of the CELL, inches (smoothed); NaN without Full 3D. */
        public double distanceIn() { return smoothedDistanceIn; }
    }

    // ---------------------------------------------------------------- state
    private final Limelight3A limelight;
    private final String problem;
    private Target target;
    /** The CELL we are locked on (0–3), or -1. */
    private int lockedCell = -1;
    private long lockedCellLastSeenNs;
    private String tagsSeen = "nothing yet";
    private final double[] distHistory = new double[15];
    private int distCount, distNext;
    private int distCell = -1;
    private long lastDistNs;

    public LimelightVision(HardwareMap hardwareMap) {
        Limelight3A ll = null;
        String why = null;
        try {
            ll = hardwareMap.get(Limelight3A.class, "limelight");
        } catch (RuntimeException e) {
            why = "no \"limelight\" in the robot config";  // the robot still drives
        }
        limelight = ll;
        problem = why;
    }

    public void start() {
        if (limelight == null) return;
        limelight.pipelineSwitch(PIPELINE);
        limelight.start();
    }

    public void stop() {
        if (limelight != null) limelight.stop();
    }

    /** Call once per loop. Returns the newest target for {@code alliance}, or null. */
    public Target update(Alliance alliance) {
        target = null;
        if (limelight == null) return null;
        long now = System.nanoTime();
        LLResult r = limelight.getLatestResult();
        if (r == null || !r.isValid() || r.getStaleness() > MAX_AGE_MS) {
            tagsSeen = "none";
            return null;
        }
        List<LLResultTypes.FiducialResult> tags = r.getFiducialResults();
        if (tags == null || tags.isEmpty()) {
            tagsSeen = "none";
            return null;
        }

        // Each CELL: its visible tags (tx always; 3D position when Full 3D gives one).
        List<List<double[]>> cellPos = new ArrayList<>();
        List<List<Integer>> cellIds = new ArrayList<>();
        double[] cellTx = new double[4];
        int[] cellCount = new int[4];
        List<List<double[]>> cellTxOff = new ArrayList<>();   // {tx, tag offset} per visible tag
        for (int i = 0; i < 4; i++) {
            cellPos.add(new ArrayList<double[]>());
            cellIds.add(new ArrayList<Integer>());
            cellTxOff.add(new ArrayList<double[]>());
        }
        LLResultTypes.FiducialResult anyBest = null;
        StringBuilder seen = new StringBuilder();

        for (LLResultTypes.FiducialResult tag : tags) {
            int id = tag.getFiducialId();
            double[] p = toTurretFrame(tag.getTargetPoseCameraSpace());
            seen.append('#').append(id).append(p == null ? "(2D) " : " ");
            if (id >= 30 && id <= 45) {
                int c = (id - 30) / 4;
                cellTx[c] += tag.getTargetXDegrees();
                cellCount[c]++;
                cellTxOff.get(c).add(new double[] {tag.getTargetXDegrees(), TAG_OFFSET_IN[(id - 30) % 4]});
                if (p != null) {
                    cellPos.get(c).add(p);
                    cellIds.get(c).add(id);
                }
            }
            if (anyBest == null || tag.getTargetArea() > anyBest.getTargetArea()) anyBest = tag;
        }
        tagsSeen = seen.toString();

        int first = alliance == Alliance.RED ? 0 : 2;
        int best = pickCell(first, cellCount, now);
        if (best < 0 && TRACK_ANY_TAG) best = pickCell(alliance == Alliance.RED ? 2 : 0, cellCount, now);

        if (best >= 0) {
            String name = (best / 2 == first / 2 ? "" : "practice: ") + CELL_NAMES[best];
            double tx = centreTx(cellTxOff.get(best), cellTx[best] / cellCount[best]);
            double[] pos = cellPos.get(best).isEmpty() ? null : cellCentre(cellPos.get(best), cellIds.get(best));
            target = makeTarget(name, cellCount[best], tx, pos, best, now);
        } else if (TRACK_ANY_TAG && anyBest != null) {
            target = makeTarget("practice tag #" + anyBest.getFiducialId(), 1, anyBest.getTargetXDegrees(),
                    toTurretFrame(anyBest.getTargetPoseCameraSpace()), -2, now);
        }
        return target;
    }

    /**
     * Which of the two CELLs starting at {@code first} to aim at, or -1. Stays on the locked CELL
     * while it is in view, and for LOCK_HOLD_MS after it drops out; only then picks the CELL
     * with the most tags.
     */
    private int pickCell(int first, int[] cellCount, long now) {
        boolean lockedHere = lockedCell == first || lockedCell == first + 1;
        if (lockedHere && cellCount[lockedCell] > 0) {
            lockedCellLastSeenNs = now;
            return lockedCell;
        }
        if (lockedHere && (now - lockedCellLastSeenNs) / 1e6 < LOCK_HOLD_MS) {
            return -1;   // our CELL blinked out: wait for it instead of jumping to the other one
        }
        int best = cellCount[first] >= cellCount[first + 1] ? first : first + 1;
        if (cellCount[best] == 0) return -1;
        lockedCell = best;
        lockedCellLastSeenNs = now;
        return best;
    }

    /**
     * The tx of the MIDDLE of the CELL from its visible tags, without 3D: the visible tags' average
     * tx, shifted along the row by how far apart the tags are in the picture (degrees per inch,
     * from the two tags furthest apart). With only 1 tag: that tag's tx.
     */
    private static double centreTx(List<double[]> txOff, double averageTx) {
        if (txOff.size() < 2) return averageTx;
        double[] lo = txOff.get(0), hi = txOff.get(0);
        double meanOff = 0;
        for (double[] t : txOff) {
            if (t[1] < lo[1]) lo = t;
            if (t[1] > hi[1]) hi = t;
            meanOff += t[1] / txOff.size();
        }
        if (hi[1] - lo[1] < 1e-9) return averageTx;
        double degPerInch = (hi[0] - lo[0]) / (hi[1] - lo[1]);
        return averageTx - degPerInch * meanOff;
    }

    /** Builds the target: aim (tx-based unless USE_3D_AIM), smoothed distance. */
    private Target makeTarget(String name, int count, double tx, double[] pos, int cell, long now) {
        double aim;
        boolean aim3d = USE_3D_AIM && pos != null;
        if (aim3d) {
            // Angle from the turret pivot to the middle of the CELL, + = right.
            aim = -Math.toDegrees(Math.atan2(pos[1], pos[0]));
        } else {
            aim = tx;
        }
        aim -= SHOT_OFFSET_DEG;

        // Smoothed distance: median of the last few frames of THIS cell.
        if (cell != distCell || (now - lastDistNs) / 1e6 > 500) {
            distCount = 0;
            distNext = 0;
            distCell = cell;
        }
        double smoothed = Double.NaN;
        if (pos != null) {
            distHistory[distNext] = Math.hypot(pos[0], pos[1]);
            distNext = (distNext + 1) % distHistory.length;
            if (distCount < distHistory.length) distCount++;
            lastDistNs = now;
        }
        if (distCount > 0) {
            int n = Math.max(1, Math.min(DISTANCE_SMOOTH_FRAMES, distCount));
            double[] recent = new double[n];
            for (int i = 0; i < n; i++) {
                recent[i] = distHistory[((distNext - 1 - i) % distHistory.length + distHistory.length) % distHistory.length];
            }
            Arrays.sort(recent);
            smoothed = recent[n / 2];
        }
        return new Target(name, count, tx, aim, pos, smoothed, aim3d);
    }

    /**
     * The CELL's centre from its visible tags: their average, moved along the row of tags so
     * it lands on the middle (needs 2+ tags; with 1 it is that tag). GitHub's CellSighting.
     */
    private static double[] cellCentre(List<double[]> pos, List<Integer> ids) {
        int n = pos.size();
        double[] c = new double[3];
        double meanOffset = 0;
        int lo = 0, hi = 0;
        for (int i = 0; i < n; i++) {
            for (int k = 0; k < 3; k++) c[k] += pos.get(i)[k] / n;
            double off = TAG_OFFSET_IN[(ids.get(i) - 30) % 4];
            meanOffset += off / n;
            if (off < TAG_OFFSET_IN[(ids.get(lo) - 30) % 4]) lo = i;
            if (off > TAG_OFFSET_IN[(ids.get(hi) - 30) % 4]) hi = i;
        }
        double span = TAG_OFFSET_IN[(ids.get(hi) - 30) % 4] - TAG_OFFSET_IN[(ids.get(lo) - 30) % 4];
        if (n >= 2 && span > 1e-9) {
            for (int k = 0; k < 3; k++) {
                double axis = (pos.get(hi)[k] - pos.get(lo)[k]) / span;
                c[k] -= axis * meanOffset;
            }
        }
        return c;
    }

    /** Camera-space pose (metres) to the turret frame (inches), or null without a 3D solution. */
    private static double[] toTurretFrame(Pose3D pose) {
        if (pose == null || pose.getPosition() == null || pose.getPosition().unit == null) return null;
        Position in = pose.getPosition().toUnit(DistanceUnit.INCH);
        if (Math.abs(in.x) < 1e-6 && Math.abs(in.y) < 1e-6 && Math.abs(in.z) < 1e-6) return null;
        return cameraToTurret(in.x, in.y, in.z);
    }

    /**
     * Camera axes (+x right, +y down, +z out of the lens) to the turret frame (+x forward,
     * +y left, +z up): tilt by the pitch, turn by the yaw, then move out to the lens. GitHub's CameraMount.
     */
    public static double[] cameraToTurret(double camX, double camY, double camZ) {
        double f = camZ, l = -camX, u = -camY;
        double p = Math.toRadians(CAM_PITCH_DEG);
        double px = f * Math.cos(p) - u * Math.sin(p);
        double pz = f * Math.sin(p) + u * Math.cos(p);
        double w = Math.toRadians(CAM_YAW_DEG);
        double x = px * Math.cos(w) - l * Math.sin(w);
        double y = px * Math.sin(w) + l * Math.cos(w);
        return new double[] {x + CAM_FORWARD_IN, y + CAM_LEFT_IN, pz + CAM_UP_IN};
    }

    // ---------------------------------------------------------------- for telemetry
    public Target target() { return target; }

    public String status() {
        if (limelight == null) return problem;
        return limelight.isConnected() ? "connected" : "NOT ANSWERING: USB cable? config?";
    }

    /** Every tag in the newest frame, e.g. "#38 #39 #40(2D)". (2D) = no 3D for that tag. */
    public String tagsSeen() { return tagsSeen; }
}