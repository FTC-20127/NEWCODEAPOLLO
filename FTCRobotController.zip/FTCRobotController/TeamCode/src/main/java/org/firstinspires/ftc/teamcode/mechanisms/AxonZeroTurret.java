package org.firstinspires.ftc.teamcode.mechanisms;

import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.CRServo;

/*
 * Servo Check (was Servo Zero): spins each turret servo on its own.
 *   turretA = servo port 0, turretB = servo port 1 (both Continuous Rotation Servo)
 *
 * Gamepad1, hold to run:
 *   X / A : turretA one way / the other     Y / B : turretB one way / the other
 *   Right bumper : both, the way Turret drives them (turretB x Turret.SERVO_B_DIR)
 *
 * X and Y turn the turret opposite ways -> mirrored, SERVO_B_DIR = -1 is right.
 * Right bumper buzzes or barely moves -> they fight: flip Turret.SERVO_B_DIR.
 */
@TeleOp(name = "Servo Check", group = "Test")
public class AxonZeroTurret extends OpMode {

    public static double TEST_POWER = 0.5;

    CRServo turretA;
    CRServo turretB;

    @Override
    public void init() {
        turretA = hardwareMap.get(CRServo.class, "turretA");
        turretB = hardwareMap.get(CRServo.class, "turretB");
    }

    @Override
    public void loop() {
        double a = 0, b = 0;
        if (gamepad1.x) a = TEST_POWER;
        else if (gamepad1.a) a = -TEST_POWER;
        else if (gamepad1.y) b = TEST_POWER;
        else if (gamepad1.b) b = -TEST_POWER;
        else if (gamepad1.right_bumper) { a = TEST_POWER; b = TEST_POWER * Turret.SERVO_B_DIR; }
        turretA.setPower(a);
        turretB.setPower(b);
        telemetry.addLine("Hold X/A = turretA, Y/B = turretB, right bumper = both");
        telemetry.addData("turretA power", "%.2f", a);
        telemetry.addData("turretB power", "%.2f", b);
    }

    @Override
    public void stop() {
        turretA.setPower(0);
        turretB.setPower(0);
    }
}
