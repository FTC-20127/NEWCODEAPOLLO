package org.firstinspires.ftc.teamcode.mechanisms;

import com.qualcomm.robotcore.hardware.AnalogInput;
import com.qualcomm.robotcore.hardware.CRServo;
import com.qualcomm.robotcore.hardware.HardwareMap;

/**
 * The turret: two continuous servos (turretA, turretB) on one gear, an AndyMark absolute encoder
 * on an analog port (turretEncoder).
 *
 * <p>TRACKING (the simple, reliable way, as in Brogan Pratt's turret tutorial): the Limelight
 * rides on the turret, so the turret just turns until the tag is in the middle of the picture.
 * The Limelight's tx (how many degrees the tag is left/right of centre) sets the power.
 * While the robot turns, the turret also counter-turns by the IMU's turn rate, so it stays on
 * the tags while you drive. Short tag dropouts (DROPOUT_HOLD_MS) are ridden through.
 * Optional (SEARCH_WHEN_LOST): when the tags are gone for longer, turn back toward where they were.
 *
 * <p>The encoder is only used for the ±TRAVEL_DEG limit (wires), measured from where the turret
 * was at INIT (its original position), and for "straight ahead".
 *
 * <p>Gearing: servos 48T → 20T shaft, 64T → 200T turret ring. Encoder 64T on the 200T ring.
 */
public class Turret {

    // ---------------------------------------------------------------- settings: check on the robot
    /**
     * Is the turret encoder (turretEncoder, analog port) plugged in AND checked? false = the code
     * never reads it: tracking uses only the camera + IMU, and there is NO wire limit, so watch
     * the wires. An unplugged analog port reads random noise, which made the turret stop at
     * random spots. Set true only after: plugged in, and in INIT, turning the turret LEFT by
     * hand makes "Turret angle" rise smoothly (no jumps).
     */
    public static boolean USE_ENCODER = false;
    /**
     * +1 if positive power turns the turret LEFT (counter-clockwise from above), -1 if RIGHT.
     * Turret turns AWAY from the tag: flip this.
     */
    public static int SERVO_DIR = 1;   // confirmed on the robot: at -1 it turned AWAY from the tag
    /** turretB against turretA: 1 = same power, -1 = opposite power. Servos buzz/fight: flip. */
    public static int SERVO_B_DIR = 1;
    /** +1 if the encoder voltage rises as the turret turns LEFT. "Turret angle" goes the wrong way: flip. */
    public static int ENCODER_DIR = 1;
    /** Encoder turns per turret turn: 200T ring / 64T encoder gear. */
    public static double ENCODER_TURNS_PER_TURRET_TURN = 200.0 / 64.0;
    /** Encoder volts with the turret straight ahead (read "Encoder volts" in INIT). NaN = zero at START. */
    public static double HOME_VOLTAGE = Double.NaN;
    /** Voltage for one encoder turn. 0 = the port's maximum (3.3 V). */
    public static double FULL_TURN_VOLTAGE = 0.0;
    /** Furthest the turret may turn each way from where it was at INIT (original position), degrees. */
    public static double TRAVEL_DEG = 180.0;

    // ---------------------------------------------------------------- settings: tracking tuning
    /** Power per degree the tag is off centre. Swings side to side: lower (0.005, 0.004). Slow: raise. */
    public static double KP = 0.0015;
    /**
     * Catch-up: when the tag is more than FAST_ZONE_DEG off centre, add KP_FAR power per degree
     * beyond that, so the turret catches up when the robot moves quickly. Near the centre only
     * the gentle KP is used, so it doesn't swing. Falls behind when moving fast: raise KP_FAR.
     */
    public static double FAST_ZONE_DEG = 8.0;
    public static double KP_FAR = 0.01;
    /** Least power that actually moves the turret (used whenever the tag is off centre). */
    public static double MIN_POWER = 0.08;
    /** Keep using the last tag reading through dropouts shorter than this, ms (no stop-start). */
    public static double DROPOUT_HOLD_MS = 150;
    /** Tag within this many degrees of centre = on target: stop pushing. */
    public static double TOLERANCE_DEG = 2.0;
    /**
     * Once on target, stay put until the tag is more than TOLERANCE_DEG + LOCK_BAND_DEG off
     * (stops the twitching back and forth around the centre).
     */
    public static double LOCK_BAND_DEG = 2.0;
    /**
     * Braking: power per (deg/s) the tag is moving toward the centre of the picture. Eases off
     * before the tag reaches the middle so the turret doesn't swing past it.
     * Keep it small: too much (0.004+) makes it swing wildly because the camera is a bit late.
     */
    public static double KD = 0.0025;
    /**
     * When the tags drop out of view, turn back toward where they were (uses the encoder + IMU).
     * OFF until ENCODER_DIR is confirmed: turn the turret LEFT by hand in INIT, "Turret angle"
     * must go UP. With ENCODER_DIR backwards this sends the turret the wrong way.
     */
    public static boolean SEARCH_WHEN_LOST = false;
    public static double MAX_POWER = 1.0;
    /**
     * Counter-turn against the robot's own turning: power per (deg/s) the robot turns.
     * About 1 / (turret deg/s at full power). Robot turns and the turret lags behind: raise.
     * Turret over-turns when the robot turns: lower. 0 = off.
     */
    public static double TURN_FF = 0.0;   // 0 = turret ignores the robot's turning (camera only)
    /** Power used to return straight ahead when tracking is off, per degree off. */
    public static double HOME_KP = 0.01;

    // ---------------------------------------------------------------- hardware and state
    private final CRServo servoA;
    private final CRServo servoB;
    private final AnalogInput encoder;

    private enum Mode { IDLE, HOME, TRACK }
    private Mode mode = Mode.IDLE;
    private boolean started;
    private double txDeg = Double.NaN;      // newest tag offset, + = tag to the RIGHT
    private double lastGoodTx = Double.NaN;
    private long lastGoodTxNs;
    private double txRateDps;               // how fast tx is changing, deg/s
    private boolean onTarget;
    private double robotTurnDps;            // robot turn rate, + = turning LEFT (from the heading)
    private double robotHeadingDeg;         // robot heading (IMU), + = left
    private double lastHeadingDeg = Double.NaN;
    private long lastHeadingNs;
    private boolean haveTagDirection;
    private double tagFieldDeg;             // which way the tags are on the field (IMU frame)
    private double lastPower;
    private String note = "";

    private double volts = Double.NaN;
    private double lastRawDeg = Double.NaN;
    private int wraps;
    private double encoderDeg;
    private double zeroEncoderDeg;
    private boolean zeroed;
    private double angleDeg;
    /** Turret angle at INIT: the wire limits are ±TRAVEL_DEG from here. */
    private double startAngleDeg;

    public Turret(HardwareMap hardwareMap) {
        servoA = hardwareMap.get(CRServo.class, "turretA");
        servoB = hardwareMap.get(CRServo.class, "turretB");
        AnalogInput enc = null;
        if (USE_ENCODER) {
            try {
                enc = hardwareMap.get(AnalogInput.class, "turretEncoder");
            } catch (RuntimeException e) {
                enc = null;   // not in the robot config: run without it
            }
        }
        encoder = enc;
    }

    private boolean encoderOn() { return USE_ENCODER && encoder != null; }

    /** At INIT: read where the turret is. Nothing moves. */
    public void init() {
        if (!encoderOn()) { angleDeg = 0; startAngleDeg = 0; return; }
        wraps = 0;
        lastRawDeg = Double.NaN;
        readEncoder();
        zeroed = false;
        if (!Double.isNaN(HOME_VOLTAGE)) {
            zeroEncoderDeg = HOME_VOLTAGE / fullTurnVolts() * 360.0;
            while (encoderDeg - zeroEncoderDeg > 180.0) zeroEncoderDeg += 360.0;
            while (encoderDeg - zeroEncoderDeg < -180.0) zeroEncoderDeg -= 360.0;
            zeroed = true;
        }
        angleDeg = ENCODER_DIR * (encoderDeg - zeroEncoderDeg) / ENCODER_TURNS_PER_TURRET_TURN;
        startAngleDeg = angleDeg;
    }

    /** At START: the servos may move from now on. */
    public void start() {
        started = true;
        if (!zeroed) {
            zeroEncoderDeg = encoderDeg;
            zeroed = true;
        }
    }

    /**
     * Track this loop. {@code tagTxDeg}: Limelight tx of the target, degrees, + = tag RIGHT of
     * centre, NaN = no tag in view. {@code robotTurnRateDps}: not used any more (the turn rate is
     * worked out from the heading, whose direction is proven by the field-relative drive).
     * {@code robotHeadingDeg}: IMU heading (yaw), + = left.
     */
    public void track(double tagTxDeg, double robotTurnRateDps, double robotHeadingDeg) {
        mode = Mode.TRACK;
        long now = System.nanoTime();
        if (!Double.isNaN(tagTxDeg)) {
            if (!Double.isNaN(lastGoodTx) && tagTxDeg != lastGoodTx) {
                double dt = (now - lastGoodTxNs) / 1e9;
                if (dt > 0.003 && dt < 0.3) txRateDps += 0.5 * ((tagTxDeg - lastGoodTx) / dt - txRateDps);
            }
            if (tagTxDeg != lastGoodTx) {
                lastGoodTx = tagTxDeg;
                lastGoodTxNs = now;
            }
            txDeg = tagTxDeg;
        } else if (!Double.isNaN(lastGoodTx) && (now - lastGoodTxNs) / 1e6 < DROPOUT_HOLD_MS) {
            txDeg = lastGoodTx;          // a frame or two without the tag: carry on
        } else {
            txDeg = Double.NaN;
        }
        // Robot turn rate from the change in heading (deg/s, + = turning left), smoothed.
        if (!Double.isNaN(lastHeadingDeg)) {
            double dt = (now - lastHeadingNs) / 1e9;
            double dh = robotHeadingDeg - lastHeadingDeg;
            if (dh > 180) dh -= 360;               // heading wraps at ±180
            if (dh < -180) dh += 360;
            if (dt > 0.001 && dt < 0.5) robotTurnDps += 0.5 * (dh / dt - robotTurnDps);
        }
        lastHeadingDeg = robotHeadingDeg;
        lastHeadingNs = now;
        this.robotHeadingDeg = robotHeadingDeg;
    }

    /** Forget where the tags were (call when the IMU heading is reset). */
    public void forgetTagDirection() { haveTagDirection = false; }

    /** Go straight ahead and stay there. */
    public void home() { mode = Mode.HOME; }

    public void idle() { mode = Mode.IDLE; }

    /** Read the encoder, work out the power, drive both servos. Call once per loop. */
    public void update() {
        if (encoderOn()) {
            readEncoder();
            angleDeg = ENCODER_DIR * (encoderDeg - zeroEncoderDeg) / ENCODER_TURNS_PER_TURRET_TURN;
        }

        double power = 0.0;                     // + = turret LEFT
        if (mode == Mode.TRACK) {
            // Counter-turn against the robot: robot turns left -> turret turns right, same speed.
            power = -TURN_FF * robotTurnDps;
            if (!Double.isNaN(txDeg)) {
                // Remember which way the tags are on the field.
                tagFieldDeg = robotHeadingDeg + angleDeg - txDeg;
                haveTagDirection = true;
                // On-target band: stop inside TOLERANCE_DEG, start again only past TOLERANCE + LOCK_BAND.
                if (Math.abs(txDeg) <= TOLERANCE_DEG) onTarget = true;
                else if (Math.abs(txDeg) > TOLERANCE_DEG + LOCK_BAND_DEG) onTarget = false;
                if (!onTarget) {
                    // Tag to the right (tx > 0) -> turn right (negative). Brake by how fast the
                    // tag is already moving toward the centre (txRate).
                    double p = -KP * txDeg - KD * txRateDps;
                    double beyond = Math.abs(txDeg) - FAST_ZONE_DEG;
                    if (beyond > 0) p -= Math.signum(txDeg) * KP_FAR * beyond;   // catch up fast
                    if (Math.signum(p) == -Math.signum(txDeg)) {
                        if (Math.abs(p) < MIN_POWER) p = Math.copySign(MIN_POWER, p);   // enough to move
                    } else {
                        p = Math.max(-MIN_POWER, Math.min(MIN_POWER, p));              // gentle brake
                    }
                    power += p;
                }
                note = onTarget ? "on target" : "tracking";
            } else if (SEARCH_WHEN_LOST && encoderOn() && haveTagDirection) {
                // Tags out of view: turn toward where they were (within the wire limits).
                double error = nearestReachable(tagFieldDeg - robotHeadingDeg) - angleDeg;
                if (Math.abs(error) > TOLERANCE_DEG) {
                    double p = KP * error;
                    if (Math.abs(p) < MIN_POWER) p = Math.copySign(MIN_POWER, p);
                    power += p;
                }
                note = "no tag: turning to where the tags were";
            } else {
                note = haveTagDirection ? "no tag: holding" : "no tag seen yet";
            }
        } else if (mode == Mode.HOME && !encoderOn()) {
            note = "tracking off (no encoder: turret just stops)";
        } else if (mode == Mode.HOME) {
            double error = -angleDeg;
            if (Math.abs(error) > 2.0) {
                power = HOME_KP * error;
                if (Math.abs(power) < MIN_POWER) power = Math.copySign(MIN_POWER, power);
            }
            note = "going straight ahead";
        } else {
            note = "idle";
        }

        // Wire limits: never push further than ±TRAVEL_DEG from the original (INIT) position.
        if (encoderOn()) {
            double fromStart = angleDeg - startAngleDeg;
            if (fromStart >= TRAVEL_DEG && power > 0) { power = 0; note = "at LEFT limit"; }
            if (fromStart <= -TRAVEL_DEG && power < 0) { power = 0; note = "at RIGHT limit"; }
        } else {
            note += " [encoder OFF: no wire limit]";
        }

        power = Math.max(-MAX_POWER, Math.min(MAX_POWER, power));
        lastPower = started ? power : 0.0;
        if (started) {
            double a = power * SERVO_DIR;
            servoA.setPower(a);
            servoB.setPower(a * SERVO_B_DIR);
        }
    }

    public void stop() {
        servoA.setPower(0);
        servoB.setPower(0);
    }

    // ---------------------------------------------------------------- helpers
    private void readEncoder() {
        volts = encoder.getVoltage();
        double raw = volts / fullTurnVolts() * 360.0;
        if (!Double.isNaN(lastRawDeg)) {         // count wraps past 3.3 V -> 0 V
            if (raw - lastRawDeg < -180.0) wraps++;
            else if (raw - lastRawDeg > 180.0) wraps--;
        }
        lastRawDeg = raw;
        encoderDeg = raw + 360.0 * wraps;
    }

    /** Same direction as {@code deg} (±360°), inside ±TRAVEL_DEG, closest to where the turret is. */
    private double nearestReachable(double deg) {
        double best = Double.NaN;
        for (int k = -3; k <= 3; k++) {
            double c = deg + 360.0 * k;
            if (Math.abs(c - startAngleDeg) > TRAVEL_DEG) continue;
            if (Double.isNaN(best) || Math.abs(c - angleDeg) < Math.abs(best - angleDeg)) best = c;
        }
        if (Double.isNaN(best)) best = Math.max(startAngleDeg - TRAVEL_DEG, Math.min(startAngleDeg + TRAVEL_DEG, deg));
        return best;
    }

    private double fullTurnVolts() {
        if (encoder == null) return 3.3;
        double v = FULL_TURN_VOLTAGE > 0 ? FULL_TURN_VOLTAGE : encoder.getMaxVoltage();
        return v > 0 ? v : 3.3;
    }

    // ---------------------------------------------------------------- for telemetry
    /** Degrees from straight ahead, + = left. */
    public double angleDeg() { return angleDeg; }
    /** Degrees from the original (INIT) position, + = left. The limit is ±TRAVEL_DEG of this. */
    public double angleFromStartDeg() { return angleDeg - startAngleDeg; }
    public double encoderVolts() { return volts; }
    public boolean homeSet() { return !Double.isNaN(HOME_VOLTAGE); }
    /** Power sent this loop, + = left. */
    public double power() { return lastPower; }
    /** What the turret is doing, in words. */
    public String note() { return note; }
}
