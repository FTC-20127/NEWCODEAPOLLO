﻿$dest = Join-Path $PSScriptRoot "TeamCode\src\main\java\org\firstinspires\ftc\teamcode\mechanisms"
$zip  = Get-ChildItem "$env:USERPROFILE\Downloads" -Filter "mechanisms*.zip" | Sort-Object LastWriteTime -Descending | Select-Object -First 1
if (-not $zip) { "No mechanisms zip found in Downloads"; exit 1 }
"Using: $($zip.Name)  (downloaded $($zip.LastWriteTime))"
$tmp = Join-Path $env:TEMP "mech_unzip"
Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue
Expand-Archive $zip.FullName -DestinationPath $tmp -Force
Get-ChildItem $tmp -Recurse -Filter *.java | Where-Object { $_.Name -notmatch '\(\d+\)' } | ForEach-Object {
    Copy-Item $_.FullName (Join-Path $dest $_.Name) -Force; "  updated $($_.Name)" }
Get-ChildItem $dest -Filter "* (*).java" | Remove-Item -Force
Get-ChildItem "$env:USERPROFILE\Downloads" -Filter "mechanisms*.zip" | Remove-Item -Force
"Done - old zips cleaned up. Press Ctrl+F9 to build, then Run."
